﻿using System.Web.UI;

namespace Togola_HW7_Part2.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}